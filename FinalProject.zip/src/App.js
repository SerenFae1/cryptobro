import Layout from './components/Layout';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import RowView from './components/RowView';
import CardView from './components/CardView';
import {Swiper, SwiperSlide} from 'swiper/react';
import 'swiper/css';

import {useState, useEffect} from 'react';
import axios from 'axios';

import './App.css';


function App() {
  const [compact, setCompact] = useState(null);
  const [data, setData] = useState(null);

  const cryptoURL = "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=100&page=1&sparkline=false&price_change_percentage=1h%2C24h%2C7d";

  useEffect(() => {
    function handleResize() {
      let width = window.innerWidth;

      if(width < 768) {
        setCompact(true);
      }
      else {
        setCompact(false);
      }

      console.log(compact);
    }

    window.addEventListener('resize', handleResize);

    const getPrices = async() =>
    {
      const response = await axios.get(cryptoURL);
      setData(response.data);
    };

    getPrices();

    return () => window.removeEventListener('resize', handleResize);
  }, [compact]);

  if(!data)
  {
    return(
      <div>
        <p>Loading...</p>
      </div>
    );
  }

  return (
    <Layout>
      <Navbar/>
        <div className='content-container'>
          { /* <div className='swiper-container'>
            <Swiper
              spaceBetween={50}
              slidesPerView={3}
              onSlideChange={() => console.log('slide change')}
              onSwiper={(swiper) => console.log(swiper)}
              >
              <SwiperSlide>
                <div className='swiper-slide'>
                  <p>Slide 1</p>
                </div>
              </SwiperSlide>
              <SwiperSlide>
                <div className='swiper-slide'>
                  <p>Slide 2</p>
                </div>
              </SwiperSlide>
              <SwiperSlide>
                <div className='swiper-slide'>
                  <p>Slide 3</p>
                </div>
              </SwiperSlide>
              <SwiperSlide>
                <div className='swiper-slide'>
                  <p>Slide 4</p>
                </div>
              </SwiperSlide>
            </Swiper>
          </div> */ }
          { compact ? (<CardView coins={data}/>) : (<div className='row-container'><RowView coins={data}/></div>) }
        </div>
      <Footer/>
    </Layout>
  );
}

export default App;
