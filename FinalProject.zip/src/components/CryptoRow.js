import './CryptoRow.css';


const CryptoRow = (props) => {
    return(
        <div className='crypto-row'>
            <div className='cell rank'>{props.rank}</div>
            <div className='cell name'>
                <img src={props.image} alt={props.name}/>
                {props.name}
            </div>
            <div className='cell price'>${props.price.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 8})}</div>
            <div className='cell one-hour'>
                {Math.round(props.oneHour * 100) / 100}%
            </div>
            <div className='cell one-day'>
                {Math.round(props.oneDay * 100) / 100}%
            </div>
            <div className='cell seven-days'>
                {Math.round(props.sevenDays * 100) / 100}%
            </div>
            <div className='cell volume'>${props.volume.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</div>
            <div className='cell market-cap'>${props.marketCap.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</div>
        </div>
    );
}


export default CryptoRow;