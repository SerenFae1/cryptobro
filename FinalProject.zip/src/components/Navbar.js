import './Navbar.css';


const Navbar = (props) => {
    return (
        <div className="background">
            <h1>Cryptocurrency Dashboard</h1>
        </div>
    );
}


export default Navbar;