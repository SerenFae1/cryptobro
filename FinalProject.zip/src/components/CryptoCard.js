import './CryptoCard.css';


const CryptoCard = (props) => {
    return(
        <div className='crypto-card'>
            <div className='left'>
                <div className='card-rank'>
                    {props.rank}
                </div>
                <div className='card-icon'>
                    <img src={props.image} alt={props.name}/>
                </div>
                <div className='card-price'>
                    ${props.price.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 8})}
                </div>
            </div>

            <div className='right'>
                <div className='card-name'>
                    {props.name}
                </div>
                <div className='right-middle'>
                    <div className='right-section card-one-hour'>
                        <div className='change-label'>1hr</div> <div className='change'>{Math.round(props.oneHour * 100) / 100}%</div>
                    </div>
                    <div className='right-section card-one-day'>
                        <div className='change-label'>24hr</div> <div className='change'>{Math.round(props.oneDay * 100) / 100}%</div>
                    </div>
                    <div className='right-section card-seven-days'>
                        <div className='change-label'>7d</div> <div className='change'>{Math.round(props.sevenDays * 100) / 100}%</div>
                    </div>
                </div>
                <div className='right-bottom'>
                    <div className='right-bottom-section'>
                        <div className='bottom-label'>Volume:</div> <div className='bottom-value'>${props.volume.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</div>
                    </div>
                    <div className='right-bottom-section'>
                        <div className='bottom-label'>Market Cap:</div> <div className='bottom-value'>${props.marketCap.toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2})}</div>
                    </div>
                </div>
            </div>
        </div>
            
    );
}


export default CryptoCard;