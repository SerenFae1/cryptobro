import './Footer.css';


const Footer = (props) => {
    return (
        <div className="background">
            <h1>Footer</h1>
        </div>
    );
}


export default Footer;