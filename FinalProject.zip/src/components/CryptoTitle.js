import './CryptoTitle.css';


const CryptoTitle = (props) => {
    return(
        <div className='title-row'>
            <div className='title-cell title-rank'>Rank</div>
            <div className='title-cell title-name'>Name</div>
            <div className='title-cell title-price'>Price</div>
            <div className='title-cell title-one-hour'>1hr</div>
            <div className='title-cell title-one-day'>24hr</div>
            <div className='title-cell title-seven-days'>7d</div>
            <div className='title-cell title-volume'>Volume</div>
            <div className='title-cell title-market-cap'>Market Cap</div>
        </div>
    );
}


export default CryptoTitle;